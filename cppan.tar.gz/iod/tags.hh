#pragma once

namespace iod
{
  struct not_found {};
  struct no_type {};
}
