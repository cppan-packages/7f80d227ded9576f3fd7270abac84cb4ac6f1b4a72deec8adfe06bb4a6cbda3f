#ifndef IOD_SYMBOL_1
#define IOD_SYMBOL_1
  iod_define_number_symbol(1)
#endif
#ifndef IOD_SYMBOL_2
#define IOD_SYMBOL_2
  iod_define_number_symbol(2)
#endif
#ifndef IOD_SYMBOL_3
#define IOD_SYMBOL_3
  iod_define_number_symbol(3)
#endif
#ifndef IOD_SYMBOL_4
#define IOD_SYMBOL_4
  iod_define_number_symbol(4)
#endif
#ifndef IOD_SYMBOL_5
#define IOD_SYMBOL_5
  iod_define_number_symbol(5)
#endif
#ifndef IOD_SYMBOL_6
#define IOD_SYMBOL_6
  iod_define_number_symbol(6)
#endif
#ifndef IOD_SYMBOL_7
#define IOD_SYMBOL_7
  iod_define_number_symbol(7)
#endif
#ifndef IOD_SYMBOL_8
#define IOD_SYMBOL_8
  iod_define_number_symbol(8)
#endif
#ifndef IOD_SYMBOL_9
#define IOD_SYMBOL_9
  iod_define_number_symbol(9)
#endif
#ifndef IOD_SYMBOL_9
#define IOD_SYMBOL_9
  iod_define_number_symbol(9)
#endif
#ifndef IOD_SYMBOL_10
#define IOD_SYMBOL_10
  iod_define_number_symbol(10)
#endif
#ifndef IOD_SYMBOL_11
#define IOD_SYMBOL_11
  iod_define_number_symbol(11)
#endif
#ifndef IOD_SYMBOL_12
#define IOD_SYMBOL_12
  iod_define_number_symbol(12)
#endif
#ifndef IOD_SYMBOL_13
#define IOD_SYMBOL_13
  iod_define_number_symbol(13)
#endif
#ifndef IOD_SYMBOL_14
#define IOD_SYMBOL_14
  iod_define_number_symbol(14)
#endif
#ifndef IOD_SYMBOL_15
#define IOD_SYMBOL_15
  iod_define_number_symbol(15)
#endif
#ifndef IOD_SYMBOL_16
#define IOD_SYMBOL_16
  iod_define_number_symbol(16)
#endif
